<footer id="footer">
	<div class="newsletter">
		<form>
			<input type="text" placeholder="Sign up ou newsletter">
			<input type="submit" value="envoyer">
	</form>
	</div>
	<div class="social">
		<a href="/" target="blank"><img src="ds" /></a>
		<a href="/" target="blank"><img src="sdf" /></a>
	</div>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>