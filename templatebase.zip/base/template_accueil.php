<?php /* Template Name: page d'accueil */ ?>

<?php get_header(); ?>


<div class="container">
  <div class="row">
    <div class="col-sm">
      One of three columns
    </div>
    <div class="col-sm">
      One of three columns
    </div>
    <div class="col-sm">
      One of three columns
    </div>
  </div>
</div>

<?php get_footer(); ?>